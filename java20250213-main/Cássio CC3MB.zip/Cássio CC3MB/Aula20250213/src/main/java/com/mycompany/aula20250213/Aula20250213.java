
package com.mycompany.aula20250213;

import java.util.Scanner;

public class Aula20250213 {

    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        int opcao;
                
        System.out.println("\t=======================");
        System.out.println("\t\tMENU");
        System.out.println("\t=======================");
        System.out.println("\t[1] - Adição (+)");
        System.out.println("\t[2] - Subtração (-)");
        System.out.println("\t[3] - Multiplicação (*)");
        System.out.println("\t[4] - Divisão (/)");
        System.out.println("\t[0] - Sair");
        
        System.out.printf("\n\tDigite a opção desejada: ");
        opcao = scan.nextInt();
        
        System.out.printf("\nO numero selecionado é: %d", opcao);

        
    }
}
